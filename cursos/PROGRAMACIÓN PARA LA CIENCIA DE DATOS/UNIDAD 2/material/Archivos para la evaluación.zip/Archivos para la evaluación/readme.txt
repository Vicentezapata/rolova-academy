# DATASETS PARA EVALUACIÓN - UNIDAD 2

## Descripción de Archivos

### 1. rendimiento_escolar.csv
- **Filas**: 45 registros
- **Columnas**: 7
- **Problemas a resolver**:
  - Fechas en 3 formatos diferentes (DD-MM-YYYY, YYYY/MM/DD, DD/MM/YYYY)
  - Nombres de regiones con mayúsculas/minúsculas inconsistentes
  - Valores atípicos (outliers) en promedio_simce
  - Registros duplicados

### 2. indicadores_regionales.json
- **Registros**: 10 regiones
- **Problemas a resolver**:
  - Valores faltantes (null) en ingreso_promedio (~20%)
  - Nombres de región no coinciden exactamente con CSV
  - Formato JSON que debe convertirse a tabular

### 3. infraestructura_educativa.csv
- **Filas**: 30 registros (3 años x 10 regiones)
- **Columnas**: 4
- **Problemas a resolver**:
  - Presupuesto en diferentes unidades (millones vs miles de millones)
  - Valores faltantes en columna "año"
  - Necesita estandarización de unidades

## Clave de Combinación
Los datasets pueden combinarse usando:
- `rendimiento_escolar.csv` y `indicadores_regionales.json`: campo región (requiere normalización)
- `indicadores_regionales.json` y `infraestructura_educativa.csv`: campo codigo_region

## Tareas Principales
1. Limpiar y estandarizar todos los datasets
2. Combinar las tres fuentes en un dataset consolidado
3. Validar que las transformaciones son correctas
4. Documentar decisiones tomadas

from pathlib import Path
import pandas as pd

# --- Config (hardcoded paths; no env/args) ---
DATA_DIR = Path(".")  # <--- se asume que los CSV están en el directorio actual

def load_products():
    # No validación de esquema, sin manejo de excepciones
    return pd.read_csv(DATA_DIR / "products.csv")

def load_orders():
    # Intencionalmente SIN parse_dates para order_date (queda como string)
    return pd.read_csv(DATA_DIR / "orders.csv")  # 'order_date' será str

def load_order_items():
    return pd.read_csv(DATA_DIR / "order_items.csv")

def load_shipments():
    # Aquí SÍ parseamos fechas (inconsistente con orders)
    return pd.read_csv(DATA_DIR / "shipments.csv", parse_dates=["shipped_date", "delivered_date"])

def load_returns():
    return pd.read_csv(DATA_DIR / "returns.csv")

def compute_gmv_wrong(orders, order_items, products):
    """
    Cálculo de GMV con error de exactitud por duplicación:
    - Une orders con order_items (correcto)
    - LUEGO hace un self-join accidental con order_items (sólo 'order_id'),
      multiplicando filas por el número de ítems por orden (n^2 por orden).
    - Además, el cálculo se realiza con un bucle fila a fila (lento).
    """
    df = orders.merge(order_items, on="order_id", how="left")
    # Self-join erróneo que multiplica filas por orden
    df = df.merge(order_items[["order_id", "product_id"]], on="order_id", how="left", suffixes=("", "_dup"))

    # Cálculo fila a fila (lento) en lugar de vectorizado
    gmv = 0
    for _, row in df.iterrows():
        # Nota: cantidad y precio unitario provienen del primer merge;
        # la columna product_id_dup sólo existe para forzar la duplicación
        if pd.notna(row.get("quantity")) and pd.notna(row.get("unit_price")):
            gmv += row["quantity"] * row["unit_price"]
    return gmv

def compute_return_rate_wrong(orders, returns, order_items):
    """
    Tasa de devoluciones mal calculada (por ítem, no por orden).
    - Une order_items con returns a nivel de item, luego divide por órdenes totales.
    - Si una orden devuelta tiene múltiples ítems, cuenta la devolución varias veces.
    """
    items_with_returns = order_items.merge(returns, on="order_id", how="inner")
    n_returns_wrong = len(items_with_returns)  # cuenta filas (ítems), no órdenes únicas
    total_orders = len(orders)
    return n_returns_wrong / total_orders if total_orders else 0.0

def compute_lead_time_apply(orders, shipments):
    """
    Lead time calculado con .apply fila a fila y parsing parcial de fechas:
    - 'order_date' viene como string (sin parse_dates)
    - Se parsea fecha por fila dentro de la función (lento e inconsistente)
    - Devuelve promedio ignorando NaN/None
    """
    delivered = orders.merge(shipments, on="order_id", how="left")
    def _lead_time_days(row):
        od = row.get("order_date")            # string
        dd = row.get("delivered_date")        # datetime64[ns] o NaT
        if pd.isna(od) or pd.isna(dd):
            return None
        try:
            od_parsed = pd.to_datetime(od)    # parsing por fila (costoso)
            return (dd - od_parsed).days
        except Exception:
            return None

    delivered["lead_time_days"] = delivered.apply(_lead_time_days, axis=1)
    # Conversión a numérico para poder sacar promedio, ignorando None/NaN
    lead_numeric = pd.to_numeric(delivered["lead_time_days"], errors="coerce")
    return float(lead_numeric.mean())

def main():
    # Sin manejo de excepciones: si falta un CSV, se cae
    products = load_products()
    orders = load_orders()
    order_items = load_order_items()
    shipments = load_shipments()
    returns = load_returns()

    gmv = compute_gmv_wrong(orders, order_items, products)
    print(f"[BASE] GMV (con duplicación inadvertida): {gmv:,.0f}")

    ret_rate = compute_return_rate_wrong(orders, returns, order_items)
    print(f"[BASE] Tasa de devoluciones (MAL, por ítem): {ret_rate:.4f}")

    lead_avg = compute_lead_time_apply(orders, shipments)
    print(f"[BASE] Lead time promedio (apply fila a fila): {lead_avg:.2f} días")

if __name__ == "__main__":
    main()

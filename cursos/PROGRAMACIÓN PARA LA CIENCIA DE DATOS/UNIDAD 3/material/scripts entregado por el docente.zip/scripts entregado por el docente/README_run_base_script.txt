Cómo ejecutar el script base (con errores intencionales):

1) Descarga estos archivos en una misma carpeta local:
   - products.csv
   - orders.csv
   - order_items.csv
   - shipments.csv
   - returns.csv
   - base_script_evaluacion3.py

2) Abre una terminal en esa carpeta y ejecuta:
   python base_script_evaluacion3.py

Notas:
- El script asume que los CSV están en el directorio actual (DATA_DIR = ".").
- No hay manejo de excepciones por diseño: si falta un CSV, el programa se detiene.
- Los cálculos (GMV, tasa de devoluciones, lead time) contienen problemas de exactitud y rendimiento para que el/la estudiante los corrija.
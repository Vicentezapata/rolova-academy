# Datasets Unidad 3 — E-commerce (Depuración y Optimización)

**Propósito:** Conjunto de datos sintéticos para la *Evaluación Final* de la Unidad 3 (“depuración y optimización de algoritmos para el análisis de datos”). Permite practicar *profiling*, vectorización, manejo de excepciones, *testing* de regresión y refactorización.

**Período simulado:** 2025-09-01 a 2025-09-30 (mes de septiembre de 2025)  
**Semilla aleatoria:** 42 (reproducible)

---

## Archivos incluidos

| Archivo | Filas | Descripción | Columnas |
|---|---:|---|---|
| `products.csv` | 2,000 | Catálogo de productos con categoría y subcategoría. | `product_id` (str), `category` (str), `subcategory` (str) |
| `orders.csv` | 50,000 | Pedidos por cliente y fecha con estado del pedido. | `order_id` (str), `customer_id` (str), `order_date` (date), `status` (str) |
| `order_items.csv` | 110,114 | Ítems por pedido: cantidad y precio unitario. | `order_id` (str), `product_id` (str), `quantity` (int), `unit_price` (int, CLP) |
| `shipments.csv` | 42,511 | Fechas de despacho/entrega (según estado). | `order_id` (str), `shipped_date` (date), `delivered_date` (date/NaT) |
| `returns.csv` | 3,994 | Órdenes devueltas y fecha de devolución. | `order_id` (str), `return_date` (date) |

**Estados en `orders`**  
- cancelled: 2399
- delivered: 39949
- placed: 5090
- shipped: 2562

---

## Diccionario de datos y supuestos

- **products.csv**
  - `product_id`: identificador único de producto (sin duplicados).
  - `category` / `subcategory`: taxonomía realista (10 categorías; 5 subcategorías c/u).

- **orders.csv**
  - `order_id`: identificador único de pedido (sin duplicados).  
  - `customer_id`: identificador del cliente.  
  - `order_date`: fecha de creación del pedido en septiembre 2025.  
  - `status`: `delivered`, `shipped`, `placed`, `cancelled` (distribución sesgada hacia `delivered`).

- **shipments.csv**
  - Incluye sólo pedidos `delivered` y `shipped`.  
  - `shipped_date` = `order_date` + 0–3 días.  
  - `delivered_date` (sólo `delivered`) = `shipped_date` + 1–7 días; los demás quedan `NaT`.

- **order_items.csv**
  - 1–5 ítems por pedido (tendencia a 1–3).  
  - `quantity` 1–5 (sesgo a 1–2).  
  - `unit_price` en CLP (distribución log-uniforme aproximada y redondeo a 10).

- **returns.csv**
  - Sólo pedidos `delivered` pueden retornar; tasa aproximada de 10%.  
  - `return_date` = `delivered_date` + 1–14 días.

---

## Advertencias de modelado (útiles para la evaluación)

- **Cardinalidades:** un `order_id` puede tener **varios** ítems en `order_items`. Evita doble conteo al calcular GMV; agrega por **orden** antes de unir con `returns` o `shipments`.
- **Tasa de devolución:** calcular por **orden** devuelta / órdenes totales (no por ítem).  
- **Fechas:** castear a `datetime64[ns]` antes de restar para “lead time” (`delivered_date - order_date`).  
- **Valores faltantes:** `delivered_date` es `NaT` para pedidos no entregados. Ajusta filtros/joins en consecuencia.
- **Rendimiento:** evita `for`/`.apply` en cálculos columnares; usa `groupby/agg`, merges con claves correctas y dtypes optimizados (`category`, `int32/float32` si aplica).

---

## Tareas sugeridas (alineadas con la evaluación)

1. **Diagnóstico y *profiling***  
   - Mide el tiempo de los pasos críticos con `cProfile`/`timeit`. Reporta antes/después.

2. **Cálculos correctos**  
   - **GMV por orden**: `sum(quantity * unit_price)` agregando `order_items` por `order_id`.  
   - **Tasa de devoluciones**: `#órdenes devueltas / #órdenes` (no por ítems).  
   - **Lead time**: `delivered_date - order_date` (en días) sólo para `delivered`.

3. **Optimización**  
   - Reemplaza bucles/`.apply` por operaciones vectorizadas (pandas/NumPy).  
   - Ajusta *dtypes* y evita trabajo redundante (cargas múltiples, merges innecesarios).

4. **Robustez**  
   - Envuelve lecturas en `try/except` (`FileNotFoundError`, `EmptyDataError`), con `logging` y conducta definida ante faltantes.

5. **Pruebas**  
   - Unitarias (funciones clave) y de **regresión**: compara salidas “antes vs. después” con datos sintéticos o subconjuntos.

---

## Ejemplos mínimos (snippet)

```python
import pandas as pd

orders = pd.read_csv("orders.csv", parse_dates=["order_date"])
items  = pd.read_csv("order_items.csv")

# GMV por orden
items["importe"] = items["quantity"] * items["unit_price"]
gmv_order = items.groupby("order_id", as_index=False)["importe"].sum()

# Tasa de devoluciones (por orden)
returns = pd.read_csv("returns.csv")
rate_returns = len(returns["order_id"].unique()) / orders["order_id"].nunique()

# Lead time (sólo entregados)
ship = pd.read_csv("shipments.csv", parse_dates=["shipped_date", "delivered_date"])
delivered = orders.merge(ship, on="order_id", how="inner")
delivered = delivered[delivered["delivered_date"].notna()].copy()
delivered["lead_time_d"] = (delivered["delivered_date"] - delivered["order_date"]).dt.days
```

---

## Sugerencias para el informe (2–4 páginas)

- **Resumen de cambios:** qué corregiste y por qué.  
- **Exactitud:** cómo evitaste doble conteo y validaste resultados (pruebas de regresión).  
- **Rendimiento:** tabla *antes vs. después* (tiempo, memoria si aplica).  
- **Riesgos y límites:** supuestos, bordes (fechas `NaT`, pedidos cancelados).

---

## Integridad y reproducibilidad

- Conjunto **sintético**, sin datos reales.  
- Generado con semilla fija (42).  
- Estructura pensada para fomentar buenas prácticas (joins correctos, vectorización, manejo de nulos, tests).

---

## Créditos y licencia

- Uso académico/docente. Puedes compartir dentro del curso citando “Datasets Unidad 3 — E-commerce (sintéticos)”.


package com.example.demo.controllers;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import entity.Usuario;

@Controller
@RequestMapping("/user")
public class UserController {
	@GetMapping({"/login"})
	public String login(Model model) {
		
		return "login";
	}
	/*@GetMapping({"/users"})
	public String users(Model model) {
		List<String> usuarios = new ArrayList<>();
		usuarios.add(0,"Vicente");
		usuarios.add(1,"Jose");
		usuarios.add(2,"Joaquin");
		usuarios.add(3,"Cesar");
		usuarios.add(4,"Margarita");
		model.addAttribute("usuarios", usuarios);
		return "forms/listUser";
	}*/
	@GetMapping({"/users"})
	public String users(Model model) {
		List<Usuario> usuarios = new ArrayList<>();
		usuarios.add(new Usuario("Vicente","Zapata","1234","vzapata@ciisa.cl","admin"));
		usuarios.add(new Usuario("Vicente2","Zapata2","1234","vzapata@ciisa.cl","admin"));
		usuarios.add(new Usuario("Vicente3","Zapata3","1234","vzapata@ciisa.cl","admin"));
		usuarios.add(new Usuario("Vicente4","Zapata4","1234","vzapata@ciisa.cl","admin"));
		usuarios.add(new Usuario("Vicente5","Zapata5","1234","vzapata@ciisa.cl","admin"));
		usuarios.add(new Usuario("Vicente6","Zapata6","1234","vzapata@ciisa.cl","admin"));
		model.addAttribute("usuarios", usuarios);
		return "forms/listUser";
	}

}

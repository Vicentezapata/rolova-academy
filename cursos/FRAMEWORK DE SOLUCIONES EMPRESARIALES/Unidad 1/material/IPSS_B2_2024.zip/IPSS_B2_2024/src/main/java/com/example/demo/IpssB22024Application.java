package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IpssB22024Application {

	public static void main(String[] args) {
		SpringApplication.run(IpssB22024Application.class, args);
	}

}

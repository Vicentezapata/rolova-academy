/* Insertar datos en tabla usuarios*/
INSERT INTO usuarios (nombre, apellido, email, password, create_at, rol) VALUES('Vicente', 'Zapata', 'vzapata@ciisa.com', '$2a$10$JF4ixF5VMTB.rbIv9ZbQveTh1ytJ6wGD4i/VQUJJk6x.MdlG5sEVK', '2023-08-03', 'ADMIN');
INSERT INTO usuarios (nombre, apellido, email, password, create_at, rol) VALUES('Jose', 'Sosa', 'jsosa@ciisa.com', '$2a$10$KthLd65Q1AlrPlfs8XlXyOHLlJsTCXw.sp8T38caXd0H7/ndtqDD6' , '2023-08-03', 'USER');
INSERT INTO usuarios (nombre, apellido, email, password, create_at, rol) VALUES('Jones', 'Gomez', 'jgomez@ciisa.com', '$2a$10$KthLd65Q1AlrPlfs8XlXyOHLlJsTCXw.sp8T38caXd0H7/ndtqDD6' , '2023-08-03', 'USER');
INSERT INTO usuarios (nombre, apellido, email, password, create_at, rol) VALUES('Williams', 'Gonzalez', 'wgonz@ciisa.com', '$2a$10$KthLd65Q1AlrPlfs8XlXyOHLlJsTCXw.sp8T38caXd0H7/ndtqDD6' , '2023-08-03', 'USER');
INSERT INTO usuarios (nombre, apellido, email, password, create_at, rol) VALUES('Camila', 'Torres', 'ctorres@ciisa.com', '$2a$10$KthLd65Q1AlrPlfs8XlXyOHLlJsTCXw.sp8T38caXd0H7/ndtqDD6' , '2023-08-03', 'USER');
INSERT INTO usuarios (nombre, apellido, email, password, create_at, rol) VALUES('Raquel', 'Martinez', 'rmartinez@ciisa.com', '$2a$10$JF4ixF5VMTB.rbIv9ZbQveTh1ytJ6wGD4i/VQUJJk6x.MdlG5sEVK', '2023-08-03', 'ADMIN');
INSERT INTO usuarios (nombre, apellido, email, password, create_at, rol) VALUES('Cristina', 'Lopez', 'clopez@ciisa.com', '$2a$10$KthLd65Q1AlrPlfs8XlXyOHLlJsTCXw.sp8T38caXd0H7/ndtqDD6' , '2023-08-03', 'USER');


INSERT INTO cocteles (nombre, descripcion, ingredientes, alcoholico,create_at,usuario_id) VALUES ( 'Margarita', 'Cóctel refrescante y cítrico con base de tequila', 'Tequila, Triple sec, Jugo de lima, Sal', true, '2023-08-03',1);

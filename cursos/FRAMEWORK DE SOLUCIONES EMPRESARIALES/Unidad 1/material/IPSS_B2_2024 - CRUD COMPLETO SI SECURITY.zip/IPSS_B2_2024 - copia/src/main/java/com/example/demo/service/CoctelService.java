package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Coctel;

public interface CoctelService {
	public List<Coctel> findAll();
	
	public void save(Coctel Coctel);
	
	public Coctel findOne(Long id);
	
	public void delete(Long id);
	
	public List<Coctel> findByNombre(String nombre);

}

package com.example.demo.controllers;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.entity.Coctel;
import com.example.demo.entity.Usuario;
import com.example.demo.service.CoctelService;
import com.example.demo.service.UsuarioService;


@Controller
@RequestMapping("/coctel")
public class CoctelController {
	
	/****************************************************************
	 *					INYECCION DE DEPENDECIAS					*
	 * **************************************************************/
	@Autowired
	private CoctelService CoctelService;
	@Autowired
	private UsuarioService usuarioService;
	
	
	
	@GetMapping({"/cocteles"})
	public String coctels(Model model) {
		//List<Coctel> Coctels = new ArrayList<>();
		List<Coctel> Coctels = CoctelService.findAll();
		//Coctels.add(new Coctel("Vicente","Zapata","1234","vzapata@ciisa.cl","admin"));
		//Coctels.add(new Coctel("+Vicente2","Zapata2","1234","vzapata@ciisa.cl","admin"));
		//Coctels.add(new Coctel("Vicente3","Zapata3","1234","vzapata@ciisa.cl","admin"));
		//Coctels.add(new Coctel("Vicente4","Zapata4","1234","vzapata@ciisa.cl","admin"));
		//Coctels.add(new Coctel("Vicente5","Zapata5","1234","vzapata@ciisa.cl","admin"));
		//Coctels.add(new Coctel("Vicente6","Zapata6","1234","vzapata@ciisa.cl","admin"));
		model.addAttribute("coctels", Coctels);
		return "forms/listCocteles";
	}
	
	
	@GetMapping({"/almacenarCoctel"})
	public String formCoctel(Model model) {
		model.addAttribute("coctel", new Coctel());
        model.addAttribute("ingredientesOpciones", List.of("Limón", "Azúcar", "Hielo", "Menta", "Ron"));
        model.addAttribute("usuarios", usuarioService.findAll()); // Para mostrar una lista de usuarios
		return "forms/formCoctel";
	}
	
	@GetMapping("/editar/{id}")
    public String mostrarFormularioEdicion(@PathVariable("id") Long id, Model model) {
        Coctel coctel = CoctelService.findOne(id);
        if (coctel == null) {
            return "redirect:/cocteles"; // Redirige si el coctel no existe
        }
        model.addAttribute("coctel", coctel);
        model.addAttribute("ingredientesOpciones", List.of("Limón", "Azúcar", "Hielo", "Menta", "Ron", "Sal"));
        model.addAttribute("usuarios", usuarioService.findAll());
        return "forms/formCoctel";
    }
	
	
	 @GetMapping("/eliminar/{id}")
	    public String eliminarCoctel(@PathVariable("id") Long id) {
		 	CoctelService.delete(id);
	        return "redirect:/coctel/cocteles";
	    }
	
	
	@PostMapping("/guardar")
    public String guardarCoctel(@ModelAttribute Coctel coctel, @RequestParam("usuario_id") Long usuarioId) {
		Usuario usuario = usuarioService.findOne(usuarioId);
        coctel.setUsuario(usuario);
        System.out.println(coctel.getId());
        if (coctel.getId() == null) {
        	System.out.println(coctel.getId());
            coctel.setCreateAt(new Date()); // Establece la fecha actual si es un nuevo coctel
        }
		CoctelService.save(coctel);
        return "redirect:cocteles";
    }
	
	

}

package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.IUsuarioDao;
import com.example.demo.entity.Usuario;
import com.example.demo.service.UsuarioService;

@Service
public class UsuarioServiceImpl implements UsuarioService{
	
	@Autowired
	private IUsuarioDao iUsuarioDao;

	@Transactional
	public List<Usuario> findAll() {
		return (List<Usuario>) iUsuarioDao.findAll();
	}

	@Transactional
	public Usuario save(Usuario usuario) {
		return iUsuarioDao.save(usuario);
		
	}

	@Transactional
	public Usuario findOne(Long id) {
		return iUsuarioDao.findById(id).orElse(null);
	}

	@Transactional
	public void delete(Long id) {
		iUsuarioDao.deleteById(id);
		
	}

	@Transactional
	public List<Usuario> findByNombre(String nombre) {
		// TODO Auto-generated method stub
		return null;
	}
	

}

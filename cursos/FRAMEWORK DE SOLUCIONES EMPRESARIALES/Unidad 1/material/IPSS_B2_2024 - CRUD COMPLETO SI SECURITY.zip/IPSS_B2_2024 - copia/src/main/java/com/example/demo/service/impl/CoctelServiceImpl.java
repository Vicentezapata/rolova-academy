package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.ICoctelDao;
import com.example.demo.entity.Coctel;
import com.example.demo.service.CoctelService;

@Service
public class CoctelServiceImpl implements CoctelService{
	
	@Autowired
	private ICoctelDao iCoctelDao;

	@Transactional
	public List<Coctel> findAll() {
		return (List<Coctel>) iCoctelDao.findAll();
	}

	@Transactional
	public void save(Coctel Coctel) {
		iCoctelDao.save(Coctel);
		
	}

	@Transactional
	public Coctel findOne(Long id) {
		return iCoctelDao.findById(id).orElse(null);
	}

	@Transactional
	public void delete(Long id) {
		iCoctelDao.deleteById(id);
		
	}

	@Transactional
	public List<Coctel> findByNombre(String nombre) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
